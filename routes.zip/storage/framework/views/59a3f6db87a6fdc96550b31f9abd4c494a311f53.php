 <div class="" style="height: 5rem"></div>
 <!-- Footer -->
 <footer class="sticky-footer bg-white fixed-bottom">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; Agenda Pimpinan UNP 2023</span>
        </div>
    </div>
</footer>
<!-- End of Footer --><?php /**PATH C:\Users\azka\Downloads\Agenda-Pimpinan-UNP (1)\Agenda-Pimpinan-UNP\resources\views/front/layout/footer.blade.php ENDPATH**/ ?>