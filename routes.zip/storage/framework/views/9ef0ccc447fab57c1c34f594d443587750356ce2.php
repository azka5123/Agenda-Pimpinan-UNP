<script src="<?php echo e(asset('dist/js/jquery-3.6.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js/iziToast.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js/summernote-bs4.js')); ?>"></script>





<?php /**PATH C:\Users\azka\Downloads\Agenda-Pimpinan-UNP (1)\Agenda-Pimpinan-UNP\resources\views/admin/layout/scripts.blade.php ENDPATH**/ ?>