<!DOCTYPE html>
<html lang="en">
<head>
    <title>Email</title>
</head>
<body>
    <p><?php echo $body; ?></p>
</body>
</html><?php /**PATH /home/uwiazxc7/public_html/Agenda-Pimpinan-UNP/resources/views/email/email.blade.php ENDPATH**/ ?>