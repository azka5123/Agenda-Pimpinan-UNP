


<script src="<?php echo e(asset('dist-front/js/jquery-3.6.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist-front/js/iziToast.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist-front/js/summernote-bs4.js')); ?>"></script>
<script src="<?php echo e(asset('dist-front/js/calender.js')); ?>"></script>








<?php /**PATH /home/uwiazxc7/public_html/Agenda-Pimpinan-UNP/resources/views/user/layout/scripts.blade.php ENDPATH**/ ?>