<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <link rel="icon" type="image/png" href="<?php echo e(asset('dist-front/img/logounp.png')); ?>" />
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
    <script src="https://cdn.ckeditor.com/ckeditor5/36.0.1/classic/ckeditor.js"></script>

    <!-- Custom fonts for this template-->
    <?php echo \Livewire\Livewire::styles(); ?>

    <?php echo $__env->make('front.layout.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('front.layout.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</head>

<body id="page-top">
    <div id="wrapper">
        
        <div div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <?php echo $__env->make('front.layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="container-fluid">

                    <?php if(session()->get('success')): ?>
                        <script>
                            iziToast.success({
                                title: '',
                                position: 'topRight',
                                message: '<?php echo e(session()->get('success')); ?>',
                            });
                        </script>
                    <?php endif; ?>

                    <?php if(session()->get('error')): ?>
                        <script>
                            iziToast.error({
                                title: '',
                                position: 'topRight',
                                message: '<?php echo e(session()->get('error')); ?>',
                            });
                        </script>
                    <?php endif; ?>

                </div>
                <?php echo $__env->yieldContent('main_content'); ?>
            </div>
            <?php echo $__env->make('front.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="<?php echo e(route('admin_logout')); ?>">Logout</a>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('front.layout.scripts_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        ClassicEditor
            .create(document.querySelector('#editor'))
            .catch(error => {
                console.error(error);
            });
    </script>
    <?php echo \Livewire\Livewire::scripts(); ?>

</body>

</html>
<?php /**PATH D:\kuliah\laravel9\1_latihan\Agenda-Pimpinan-UNP\resources\views/front/layout/app.blade.php ENDPATH**/ ?>