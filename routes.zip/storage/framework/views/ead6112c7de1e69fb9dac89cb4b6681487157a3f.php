

<?php $__env->startSection('title', 'Jadwal'); ?>


<?php $__env->startSection('main_content'); ?>
    <h1 class="h3 mb-2 text-gray-800">Jadwal</h1>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-info"><a href="<?php echo e(route('create_jadwal')); ?>" class="btn btn-info">
                    <i class="fas fa-plus"></i>Add Agenda</a></h6>
        </div>

        <div class="card-body">
            <div class="container-fluid" id="calendar"></div>
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    var calendarEl = document.getElementById('calendar');
                    var calendar = new FullCalendar.Calendar(calendarEl, {
                        initialView: 'dayGridMonth',
                        slotMinTime: '7:00:00',
                        slotMaxTime: '18:00:00',
                        headerToolbar: {
                            left: 'dayGridMonth,timeGridWeek,timeGridDay',
                            center: 'title',
                            right: 'today prev,next'
                        },
                        events: <?php echo json_encode($events, 15, 512) ?>,
                        dayMaxEventRows: 2,
                        selectable: true,
                    });
                    calendar.render();
                });
            </script>



        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/uwiazxc7/public_html/Agenda-Pimpinan-UNP/resources/views/user/jadwal/show_jadwal.blade.php ENDPATH**/ ?>