 <!-- Sidebar -->
 <ul class="navbar-nav bg-info sidebar sidebar-dark accordion" id="accordionSidebar">

     <!-- Sidebar - Brand -->
     
     <div class="sidebar-heading mt-3 text-light">
         <h6><i class="fa fa-bars" aria-hidden="true"></i>&nbsp;
             Menu</h6>
     </div>

     <!-- Divider -->
     <hr class="sidebar-divider my-0">

     

     <!-- Divider -->
     <hr class="sidebar-divider">

     <!-- Heading -->

     <li class="nav-item">
         <a class="nav-link" href="<?php echo e(route('show_jadwal')); ?>">
             <i class='fa-solid fa-calendar-days'></i>&nbsp;<span>Jadwal</span></a>
     </li>
     

     <li class="nav-item">
         <a class="nav-link" href="<?php echo e(route('user_logout')); ?>" data-toggle="modal" data-target="#logoutModal">
             <i class="fa fa-sign-out" aria-hidden="true"></i>
             <span>Logout</span></a>
     </li>

     

     <!-- advertisements -->
     

     <!-- category, sub category, post -->
     

     
     

     
     

     <!-- about, faq, disclaimer, contact, login, etc -->
     

     
     

 </ul>

 <!-- End of Sidebar -->
<?php /**PATH D:\kuliah\laravel9\1_latihan\Agenda-Pimpinan-UNP\resources\views/user/layout/sidebar.blade.php ENDPATH**/ ?>