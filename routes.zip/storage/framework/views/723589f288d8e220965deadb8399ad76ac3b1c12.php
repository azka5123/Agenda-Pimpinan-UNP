

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="<?php echo e(asset('dist-front/css/popover.css')); ?>">
</head>

<body>
    <div>
        

    </div>
    
    <div class="overlay"></div>
    <div class="overlayed">
        <div class="modal-header">
            <h5 class="title text-dark"><?php echo e($edit->title); ?></h5>
            <a href="<?php echo e(route('show_jadwal')); ?>"><button type="button" class="btn-close" data-dismiss="modal"
                    aria-label="Close">
                    &times;
                </button></a>
        </div>
        <div class="overlayed-content">
            <div class="overlayed-title"><strong> Kegiatan: </strong><?php echo e($edit->title); ?></div>
            <div class="overlayed-time"><strong>Waktu Mulai:</strong>
                <?php echo e($edit->start_time->isoFormat('dddd, D MMM Y HH:m')); ?></div>
            <div class="overlayed-time"><strong>Berakhir:
                </strong><?php echo e($edit->finish_time->isoFormat('dddd, D MMM Y HH:m')); ?></div>
            <div class="overlayed-description"><strong>Keterangan: </strong>
                <textarea class="form-control" name="keterangan" rows="4" value=""><?php echo e($edit->keterangan); ?></textarea>
            </div>
        </div>

        <div class="modal-footer">
            <a href="<?php echo e(route('edit_jadwal', $edit->id)); ?>"><button type="button" class="btn btn-sm btn-warning"
                    data-bs-toggle="modal">Edit</button></a>
            <a href="<?php echo e(route('delete_jadwal', $edit->id)); ?>"><button type="button" class="btn btn-sm btn-danger"
                    data-bs-toggle="modal">Delete</button></a>
        </div>
    </div>

    
</body>

</html>

<?php echo $__env->make('user.jadwal.show_jadwal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kuliah\laravel9\1_latihan\Agenda-Pimpinan-UNP\resources\views/user/jadwal/popover.blade.php ENDPATH**/ ?>