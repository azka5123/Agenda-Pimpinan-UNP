 <!-- Sidebar -->
 <ul class="navbar-nav bg-info sidebar sidebar-dark accordion" id="accordionSidebar">

     <!-- Sidebar - Brand -->
     <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(route('admin_user_show')); ?>">
         <div class="sidebar-brand-icon rotate-n-15">
             <i class="fas fa-laugh-wink"></i>
         </div>
         <div class="sidebar-brand-text mx-3"><?php echo e(Auth::user()->name); ?></div>
     </a>

     <!-- Divider -->
     <hr class="sidebar-divider my-0">


     <!-- Heading -->
     <div class="sidebar-heading">
         Menu
     </div>

     <hr class="sidebar-divider my-0">

     <li class="nav-item">
         <a class="nav-link" href="<?php echo e(route('admin_user_show')); ?>">
             <i class="fas fa-fw fa-tachometer-alt">
             </i><span>User</span></a>
     </li>

     <li class="nav-item">
         <a class="nav-link" href="#" data-toggle="modal" data-target="#logoutModal">
             <i class="fas fa-fw fa-tachometer-alt"></i>
             <span>Logout</span></a>
     </li>

     

     <!-- advertisements -->
     

     <!-- category, sub category, post -->
     

     
     

     
     

     <!-- about, faq, disclaimer, contact, login, etc -->
     

     
     

 </ul>

 <!-- End of Sidebar -->
<?php /**PATH C:\Users\azka\Downloads\Agenda-Pimpinan-UNP (1)\Agenda-Pimpinan-UNP\resources\views/admin/layout/sidebar.blade.php ENDPATH**/ ?>