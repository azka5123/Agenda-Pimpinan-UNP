



<!-- Bootstrap core JavaScript-->
<script src="<?php echo e(asset('dist/vendor/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.4/moment-with-locales.min.js"
    integrity="sha512-42PE0rd+wZ2hNXftlM78BSehIGzezNeQuzihiBCvUEB3CVxHvsShF86wBWwQORNxNINlBPuq7rG4WWhNiTVHFg=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<!-- Core plugin JavaScript-->
<script src="<?php echo e(asset('dist/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

<!-- Custom scripts for all pages-->
<script src="<?php echo e(asset('dist/js/sb-admin-2.min.js')); ?>"></script>


<script>
    // Ambil referensi elemen select date
    var selectedDate = localStorage.getItem('selectedDate');
    var select = moment(selectedDate);
    var select2 = select.local().format("YYYY-MM-DD HH:mm");
    var date1 = document.getElementById('date1')
    var date2 = document.getElementById('date2')
    // Tambahkan event listener pada date2
    date1.value = select2;
    date2.value = select2;
    localStorage.removeItem('selectedDateTime');
    date2.addEventListener('change', function() {

        if (date2.value < date1.value) {
            iziToast.error({
                // title: 'Error',
                message: 'tanggal berakhir harus lebih besar dari tanggal mulai',
                position: 'topRight'
            });
            date2.value = date1.value;
        }
    });
    date1.addEventListener('change', function() {

        if (date1.value > date2.value) {
            iziToast.error({
                // title: 'Error',
                message: 'tanggal mulai harus lebih kecil dari tanggal berakhir',
                position: 'topRight'
            });
            date1.value = date2.value;
        }
    });
</script>
<?php /**PATH D:\kuliah\laravel9\1_latihan\Agenda-Pimpinan-UNP\resources\views/user/layout/scripts_footer.blade.php ENDPATH**/ ?>