<!-- Bootstrap core JavaScript-->
<script src="<?php echo e(asset('dist-front/vendor/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist-front/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

<!-- Core plugin JavaScript-->
<script src="<?php echo e(asset('dist-front/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

<!-- Custom scripts for all pages-->
<script src="<?php echo e(asset('dist-front/js/sb-admin-2.min.js')); ?>"></script>

<!-- Page level plugins -->
<script src="<?php echo e(asset('dist-front/vendor/chart.js/Chart.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist-front/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist-front/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>


<!-- Page level custom scripts -->
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<?php /**PATH /home/uwiazxc7/public_html/Agenda-Pimpinan-UNP/resources/views/front/layout/scripts_footer.blade.php ENDPATH**/ ?>