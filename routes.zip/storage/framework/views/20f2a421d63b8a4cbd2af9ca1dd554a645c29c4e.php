

<?php $__env->startSection('title', 'Agenda Pimpinan UNP'); ?>

<?php $__env->startSection('main_content'); ?>
    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user-data', [])->html();
} elseif ($_instance->childHasBeenRendered('9NtO5fk')) {
    $componentId = $_instance->getRenderedChildComponentId('9NtO5fk');
    $componentTag = $_instance->getRenderedChildComponentTagName('9NtO5fk');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('9NtO5fk');
} else {
    $response = \Livewire\Livewire::mount('user-data', []);
    $html = $response->html();
    $_instance->logRenderedChild('9NtO5fk', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        <div class="container-fluid" id="calendar"></div>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                var calendarEl = document.getElementById('calendar');
                var calendar = new FullCalendar.Calendar(calendarEl, {
                    initialView: 'dayGridMonth',
                    slotMinTime: '7:00:00',
                    slotMaxTime: '18:00:00',
                    headerToolbar: {
                        left: 'dayGridMonth,timeGridWeek,timeGridDay',
                        center: 'title',
                        right: 'today prev,next'
                    },
                    events: <?php echo json_encode($events, 15, 512) ?>,
                    dayMaxEventRows: 2,
                    selectable: true,
                });
                // return calendar.formatRange(events);
                calendar.render();
            });
        </script>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\azka\Downloads\Agenda-Pimpinan-UNP (1)\Agenda-Pimpinan-UNP\resources\views/front/home.blade.php ENDPATH**/ ?>