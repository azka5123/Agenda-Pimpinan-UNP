<!DOCTYPE html>
<html lang="en">
<head>
    <title>Email</title>
</head>
<body>
    <p><?php echo $body; ?></p>
</body>
</html><?php /**PATH C:\Users\azka\Downloads\Agenda-Pimpinan-UNP (1)\Agenda-Pimpinan-UNP\resources\views/email/email.blade.php ENDPATH**/ ?>