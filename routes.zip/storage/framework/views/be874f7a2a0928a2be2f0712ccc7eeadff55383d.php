<link rel="stylesheet" href="<?php echo e(asset('dist/css/sb-admin-2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist/vendor/fontawesome-free/css/all.min.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('dist/css/iziToast.min.css')); ?>">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
    integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />




<?php /**PATH D:\kuliah\laravel9\1_latihan\Agenda-Pimpinan-UNP\resources\views/user/layout/styles.blade.php ENDPATH**/ ?>