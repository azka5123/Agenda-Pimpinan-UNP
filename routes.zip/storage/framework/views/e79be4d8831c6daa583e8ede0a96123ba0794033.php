<link rel="stylesheet" href="<?php echo e(asset('dist-front/css/sb-admin-2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist-front/vendor/fontawesome-free/css/all.min.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('dist-front/css/iziToast.min.css')); ?>">
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

<link rel="stylesheet" href="<?php echo e(asset('dist-front/css/style.css')); ?>">

<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Lato&family=Poppins:ital,wght@1,300&display=swap" rel="stylesheet">
<?php /**PATH D:\kuliah\laravel9\1_latihan\Agenda-Pimpinan-UNP\resources\views/front/layout/styles.blade.php ENDPATH**/ ?>