<link rel="stylesheet" href="<?php echo e(asset('dist-front/css/sb-admin-2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist-front/vendor/fontawesome-free/css/all.min.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('dist-front/css/iziToast.min.css')); ?>">
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<?php /**PATH C:\Users\azka\Downloads\Agenda-Pimpinan-UNP (1)\Agenda-Pimpinan-UNP\resources\views/front/layout/styles.blade.php ENDPATH**/ ?>