<link rel="stylesheet" href="<?php echo e(asset('dist/css/sb-admin-2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist/vendor/fontawesome-free/css/all.min.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('dist/css/iziToast.min.css')); ?>">




<?php /**PATH /home/uwiazxc7/public_html/Agenda-Pimpinan-UNP/resources/views/user/layout/styles.blade.php ENDPATH**/ ?>