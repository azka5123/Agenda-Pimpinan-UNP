

<?php $__env->startSection('heading', 'Jadwal Edit'); ?>

<?php $__env->startSection('main_content'); ?>
    <div class="section-body">
        <form action="<?php echo e(route('update_jadwal', $edit->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <h5>Edit Jadwal</h5>
                        <div class="card-body">
                            <div class="form-group mb-3">
                                <label>Nama</label>
                                <input type="text" class="form-control" name="tanggal" value="<?php echo e(Auth::user()->nama); ?>"
                                    readonly>
                            </div>
                            <div class="form-group mb-3">
                                <label>Nama Kegiatan</label>
                                <input type="text" class="form-control" name="title" value="<?php echo e($edit->title); ?>">
                            </div>
                            <div class="form-group mb-3">
                                <label>Tanggal Mulai</label>
                                <input type="datetime-local" class="form-control" name="start_time"
                                    value="<?php echo e($edit->start_time); ?>" id="date1">
                            </div>
                            <div class="form-group mb-3">
                                <label>Tanggal Berakhir</label>
                                <input type="datetime-local" class="form-control" name="finish_time"
                                    value="<?php echo e($edit->finish_time); ?>" id="date2">
                            </div>
                            <div class="form-group mb-3">
                                <label>Keterangan</label>
                                <textarea class="form-control" name="keterangan" rows="5" value=""><?php echo e($edit->keterangan); ?></textarea>

                            </div>

                            <div class="form-group">
                                <button type="submit" class="btn btn-info">Submit</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kuliah\laravel9\1_latihan\Agenda-Pimpinan-UNP\resources\views/user/jadwal/edit_jadwal.blade.php ENDPATH**/ ?>