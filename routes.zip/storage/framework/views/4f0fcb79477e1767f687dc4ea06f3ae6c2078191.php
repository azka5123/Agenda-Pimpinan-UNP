

<?php $__env->startSection('title', 'rekap'); ?>

<?php $__env->startSection('main_content'); ?>
    <h1 class="h3 mb-2 text-gray-800">rekap</h1>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"><a href="<?php echo e(route('admin_user_export', $user->id)); ?>"
                    class="btn btn-info">
                    <i class='fas fa-file-export'></i> Export to excel</a></h6>
        </div>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <tr>
                        <td colspan="6" rowspan="2" align="center"><b>Rekap Jadwal <?php echo e($user->nama); ?></b></td>
                    </tr>
                    <tr>
                        <td></td>
                    </tr>

                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Nama kegiatan</th>
                        <th>Keterangan</th>
                        <th>Waktu mulai</th>
                        <th>Waktu berakhir</th>
                    </tr>

                    <tfoot>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Nama kegiatan</th>
                            <th>Keterangan</th>
                            <th>Waktu mulai</th>
                            <th>Waktu berakhir</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($item->rUser->nama); ?></td>
                                <td><?php echo e($item->title); ?></td>
                                <td><?php echo e($item->keterangan); ?></td>
                                <td><?php echo e($item->start_time); ?></td>
                                <td><?php echo e($item->finish_time); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kuliah\laravel9\1_latihan\Agenda-Pimpinan-UNP\resources\views/admin/user/user_rekap.blade.php ENDPATH**/ ?>