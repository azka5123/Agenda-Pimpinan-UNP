<div class="row my-3">
    <div class="col-12">
        <ul class="list-group">
            <li class="list-group-item"><input class="form-control" type="text" wire:model="search" placeholder="Search"
                    aria-label="search"></li>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($search == ''): ?>
                <?php else: ?>
                    <li class="list-group-item">
                        <a href="<?php echo e(route('front_show2', $item->nama)); ?>" class="text-decoration-none text-dark px-1">
                            <i class="fas fa-fw fa-user-alt">
                            </i><span>
                                <?php echo e($item->nama); ?> - <?php echo e($item->jabatan); ?>

                            </span>
                        </a>
                    </li>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>
<?php /**PATH C:\Users\azka\Downloads\Agenda-Pimpinan-UNP (1)\Agenda-Pimpinan-UNP\resources\views/livewire/user-data.blade.php ENDPATH**/ ?>