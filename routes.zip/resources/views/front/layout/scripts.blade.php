<script src="{{ asset('dist-front/js/jquery-3.6.0.min.js') }}"></script>
<script src="{{ asset('dist-front/js/calender.js') }}"></script>
<script src="{{ asset('dist-front/js/iziToast.min.js') }}"></script>
<script src="{{ asset('dist-front/js/summernote-bs4.js') }}"></script>

<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
