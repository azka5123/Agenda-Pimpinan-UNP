<link rel="stylesheet" href="{{ asset('dist/css/sb-admin-2.min.css') }}">
<link rel="stylesheet" href="{{ asset('dist/vendor/fontawesome-free/css/all.min.css') }}" type="text/css">
<link rel="stylesheet" href="{{ asset('dist/css/iziToast.min.css') }}">

{{-- 
<link rel="stylesheet" href="{{ asset('dist/css/bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ asset('dist/css/bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ asset('dist/css/summernote-bs4.css') }}">
<link rel="stylesheet" href="{{ asset('dist/css/font_awesome_5_free.min.css') }}">
<link rel="stylesheet" href="{{ asset('dist/css/select2.min.css') }}">
<link rel="stylesheet" href="{{ asset('dist/css/bootstrap-datepicker.min.css') }}">
<link rel="stylesheet" href="{{ asset('dist/css/bootstrap-timepicker.min.css') }}">
<link rel="stylesheet" href="{{ asset('dist/css/bootstrap-tagsinput.css') }}">
<link rel="stylesheet" href="{{ asset('dist/css/duotone-dark.css') }}">
<link rel="stylesheet" href="{{ asset('dist/css/dataTables.bootstrap4.min.css') }}">
<link rel="stylesheet" href="{{ asset('dist/css/iziToast.min.css') }}">
<link rel="stylesheet" href="{{ asset('dist/css/fontawesome-iconpicker.min.css') }}">
<link rel="stylesheet" href="{{ asset('dist/css/bootstrap4-toggle.min.css') }}">
<link rel="stylesheet" href="{{ asset('dist/css/summernote-bs4.css') }}">
<link rel="stylesheet" href="{{ asset('dist/css/style.css') }}">
<link rel="stylesheet" href="{{ asset('dist/css/components.css') }}">
<link rel="stylesheet" href="{{ asset('dist/css/spacing.css') }}">
<link rel="stylesheet" href="{{ asset('dist/css/custom.css') }}"> --}}
{{-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/izitoast/1.4.0/css/iziToast.css" integrity="sha512-DIW4FkYTOxjCqRt7oS9BFO+nVOwDL4bzukDyDtMO7crjUZhwpyrWBFroq+IqRe6VnJkTpRAS6nhDvf0w+wHmxg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/izitoast/1.4.0/css/iziToast.min.css" integrity="sha512-O03ntXoVqaGUTAeAmvQ2YSzkCvclZEcPQu1eqloPaHfJ5RuNGiS4l+3duaidD801P50J28EHyonCV06CUlTSag==" crossorigin="anonymous" referrerpolicy="no-referrer" /> --}}
{{-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.3/css/dataTables.bootstrap5.min.css"> --}}
