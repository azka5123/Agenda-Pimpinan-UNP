 <!-- Sidebar -->
 <ul class="navbar-nav bg-info sidebar sidebar-dark accordion" id="accordionSidebar">

     <!-- Sidebar - Brand -->
     <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(route('user_dashboard')); ?>">
         <div class="sidebar-brand-icon rotate-n-15">
             <i class="fas fa-laugh-wink"></i>
         </div>
         <div class="sidebar-brand-text mx-3"><?php echo e(Auth::user()->nama); ?></div>
     </a>

     <!-- Divider -->
     <hr class="sidebar-divider my-0">

     

     <!-- Divider -->
     <hr class="sidebar-divider">

     <!-- Heading -->
     <div class="sidebar-heading">
         Menu
     </div>

     <li class="nav-item">
         <a class="nav-link" href="<?php echo e(route('show_jadwal')); ?>">
             <i class="fas fa-fw fa-tachometer-alt">
             </i><span>Jadwal</span></a>
     </li>

     <li class="nav-item">
         <a class="nav-link" href="<?php echo e(route('show_all_jadwal')); ?>">
             <i class="fas fa-fw fa-tachometer-alt">
             </i><span>All Agenda</span></a>
     </li>

     <li class="nav-item">
         <a class="nav-link" href="<?php echo e(route('user_logout')); ?>" data-toggle="modal" data-target="#logoutModal">
             <i class="fas fa-fw fa-tachometer-alt"></i>
             <span>Logout</span></a>
     </li>

     

     <!-- advertisements -->
     

     <!-- category, sub category, post -->
     

     
     

     
     

     <!-- about, faq, disclaimer, contact, login, etc -->
     

     
     

 </ul>

 <!-- End of Sidebar -->
<?php /**PATH D:\kuliah\laravel9\1_latihan\Agenda-Pimpinan-UNP\resources\views/user/layout/sidebar.blade.php ENDPATH**/ ?>