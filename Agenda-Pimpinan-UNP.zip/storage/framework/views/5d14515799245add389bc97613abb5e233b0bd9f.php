

<?php $__env->startSection('heading', 'User Create'); ?>

<?php $__env->startSection('main_content'); ?>
    <div class="section-body">
        <form action="<?php echo e(route('admin_user_store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <h5>Create User</h5>
                        <div class="card-body">
                            <div class="form-group mb-3">
                                <label>Nama</label>
                                <input type="text" class="form-control" name="nama">
                            </div>
                            <div class="form-group mb-3">
                                <label>Email</label>
                                <input type="email" class="form-control" name="email">
                            </div>
                            <div class="form-group mb-3">
                                <label>Jabatan</label>
                                <input type="text" class="form-control" name="jabatan">
                            </div>
                            <div class="form-group mb-3">
                                <label>Password</label>
                                <input type="password" class="form-control" name="password">
                            </div>
                            <div class="form-group mb-3">
                                <label>Retype Password</label>
                                <input type="password" class="form-control" name="password_confirmation">
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kuliah\laravel9\1_latihan\Agenda-Pimpinan-UNP\resources\views/admin/user/user_create.blade.php ENDPATH**/ ?>