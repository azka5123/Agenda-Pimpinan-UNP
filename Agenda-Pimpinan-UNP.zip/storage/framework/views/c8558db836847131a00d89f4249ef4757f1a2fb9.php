 <!-- Sidebar -->
 <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

     <!-- Sidebar - Brand -->
     

     <!-- Divider -->
     <hr class="sidebar-divider my-0">

     
     <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user-data', [])->html();
} elseif ($_instance->childHasBeenRendered('3gY2xkw')) {
    $componentId = $_instance->getRenderedChildComponentId('3gY2xkw');
    $componentTag = $_instance->getRenderedChildComponentTagName('3gY2xkw');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('3gY2xkw');
} else {
    $response = \Livewire\Livewire::mount('user-data', []);
    $html = $response->html();
    $_instance->logRenderedChild('3gY2xkw', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
     
     <!-- Divider -->
    
     

     <!-- advertisements -->
     

     <!-- category, sub category, post -->
     

     
     

     
     

     <!-- about, faq, disclaimer, contact, login, etc -->
     

     
     

 </ul>

 <!-- End of Sidebar -->
<?php /**PATH D:\kuliah\laravel9\1_latihan\Agenda-Pimpinan-UNP\resources\views/front/layout/sidebar.blade.php ENDPATH**/ ?>