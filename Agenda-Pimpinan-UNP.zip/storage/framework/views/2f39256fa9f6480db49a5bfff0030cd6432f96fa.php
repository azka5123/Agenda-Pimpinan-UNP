

<?php $__env->startSection('title', 'Jadwal'); ?>

<?php $__env->startSection('main_content'); ?>

    <link rel="stylesheet" href="<?php echo e(asset('dist/css/style.css')); ?>">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <h1 class="h3 mb-2 text-gray-800">Agenda List</h1>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">

        <div class="card-body">
            <div type="text" class="h3 mb-3 text-gray-800"><h5>My Agenda</h5></div>
            <div class="notcomp">
            

                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="task bg-info text-white">
                   
                    <?php echo e($loop->iteration); ?>. <?php echo e($item->keterangan); ?>, ( <?php echo e($item->start_time); ?> )
                    <a href="<?php echo e(route('delete_jadwal', $item->id)); ?>"> <i class="fas fa-trash-alt text-white"></i></a>
                    <a href="<?php echo e(route('edit_jadwal', $item->id)); ?>"> <i class="fas fa-edit text-white"> Edit</i></a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?> 

<?php echo $__env->make('user.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kuliah\laravel9\1_latihan\Agenda-Pimpinan-UNP\resources\views/user/jadwal/all.blade.php ENDPATH**/ ?>