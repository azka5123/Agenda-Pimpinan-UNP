<link rel="stylesheet" href="<?php echo e(asset('dist/css/sb-admin-2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist/vendor/fontawesome-free/css/all.min.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('dist/css/iziToast.min.css')); ?>">




<?php /**PATH D:\kuliah\laravel9\1_latihan\Agenda-Pimpinan-UNP\resources\views/admin/layout/styles.blade.php ENDPATH**/ ?>