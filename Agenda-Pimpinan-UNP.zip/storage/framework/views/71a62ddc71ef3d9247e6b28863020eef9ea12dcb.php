

<?php $__env->startSection('title', 'User'); ?>

<?php $__env->startSection('main_content'); ?>
    <h1 class="h3 mb-2 text-gray-800">User</h1>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"><a href="<?php echo e(route('admin_user_create')); ?>" class="btn btn-info">
                    <i class="fas fa-plus"></i>Add User</a></h6>
        </div>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Jabatan</th>
                            <th>Email</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Jabatan</th>
                            <th>Email</th>
                            <th>Action</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($item->nama); ?></td>
                                <td><?php echo e($item->jabatan); ?></td>
                                <td><?php echo e($item->email); ?></td>
                                <td><a href="<?php echo e(route('admin_user_edit', $item->id)); ?>" class="btn btn-warning"> <i
                                            class="fas fa-edit"></i>edit</a>
                                    <a href="<?php echo e(route('admin_user_delete', $item->id)); ?>" class="btn btn-danger"
                                        onclick="return confirm('are u sure?')"> <i class="fas fa-trash"></i>delete</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kuliah\laravel9\1_latihan\Agenda-Pimpinan-UNP\resources\views/admin/user/user_show.blade.php ENDPATH**/ ?>