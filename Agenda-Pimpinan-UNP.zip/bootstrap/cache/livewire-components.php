<?php return array (
  'user-data' => 'App\\Http\\Livewire\\UserData',
);